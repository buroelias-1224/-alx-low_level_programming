#idndef FILE_MAIN
#define FILE_MAIN

int _putchar(char c);

#endif
