#ifndef LISTS_H
#define LISTS_H
#include <stddef.h>
/**
 * struct list_s - Singly Linked List
 * @str: string - (malloc'edstring)
 * @len: Lenght of the string
 * @next: points to the next node
 *
 * Description: list in which every node contains some data and a
 * pointer to the next node of the same data type
 */

typedef struct list_s
{
	char *str;
	unsigned int len;
	struct list_s *next;
} list_t;


size_t print_list(const list_t *h);
size_t list_len(const list_t *h);
list_t *add_node(list_t **head, const char *str);
list_t *add_node_end(list_t **head, const char *str);
void free_list(list_t *head);



#endif
