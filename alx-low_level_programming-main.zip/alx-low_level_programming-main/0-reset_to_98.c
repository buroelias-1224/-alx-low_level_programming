#include "main.h"

/**
 * reset_to_98 - This function returns the update value of a pointer
 * @n: The variable pointer passed
 *
 * Return: void
 */

void reset_to_98(int *n)
{

	*n = 98;

}
