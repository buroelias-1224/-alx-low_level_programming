## 0x03. C - Debugging

 ###  Tasks
   ### 0. Multiple mains
     In most projects, we often give you only one main file to test with. For example,
     this main file is a test for a postitive_or_negative() function similar to the one you worked with in an earlier C project: