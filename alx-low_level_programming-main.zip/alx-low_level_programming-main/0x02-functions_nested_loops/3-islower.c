#include  "main.h"


/**
 * _islower - print_alphabet
 * @c: its mine damnit
 *
 * Return: 1 if lowercase and 0 otherwise;
 * Does my stuff explained.
 */

int _islower(int c)
{
	if (c > 96 && c < 123)
	{
		return (1);
	}

	else
	{
		return (0);
	}
}
