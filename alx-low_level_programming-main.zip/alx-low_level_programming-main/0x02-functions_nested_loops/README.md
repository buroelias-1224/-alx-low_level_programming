## 0x02. C - Functions, nested loops

## Tasks
### 0. _putchar
    Write a program that prints _putchar, followed by a new line.

    The program should return 0