#include  "main.h"


/**
 * _abs - print_alphabet
 * @c: its mine damnit
 *
 * Return: 1 if lowercase and 0 otherwise;
 * Does my stuff explained.
 */

int _abs(int c)
{
	if (c > 0)
	{
		return (c);
	}
	return (-c);
}
