
#include "main.h"

/**
 * print_numbers - This function print numbers
 *
 * return: nothing
 */

void print_numbers(void)
{
	int i;

	i = 48;
	while (i < 58)
	{
		_putchar(i);
		i++;
	}
	_putchar('\n');
}
