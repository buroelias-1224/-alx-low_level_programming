#include "main.h"

/**
 * mul - Multiply two integers
 * @a: first integer
 * @b: Second integer
 * Return: the result ofthe multiplication
 */

int mul(int a, int b)
{
	int mult;

	mult = (a * b);
	return (mult);
}
