## 0x01. C - Variables, if, else, while

### Tasks
#### 0. Positive anything is better than negative nothing
mandatory

This program will assign a random number to the variable n each time it is executed. Complete the source code in order to print whether the number stored in the variable n is positive or negative.
You can find the source code here
The variable n will store a different value every time you will run this program
You don’t have to understand what rand, srand, RAND_MAX do. Please do not touch this code
The output of the program should be:
The number, followed by if the number is greater than 0: is positive if the number is 0: is  if the number is less than 0: is negative followed by a new line
								    