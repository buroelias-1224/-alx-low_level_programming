#include <stdio.h>


/**
 * main - Prints the name of the file
 * Return: 0(Success) Always
 */

int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
